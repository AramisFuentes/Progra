﻿namespace L8_AF1092022
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbl10X10 = new System.Windows.Forms.Label();
            this.lbl10X7 = new System.Windows.Forms.Label();
            this.lbl10X9 = new System.Windows.Forms.Label();
            this.lbl10X8 = new System.Windows.Forms.Label();
            this.lbl10X6 = new System.Windows.Forms.Label();
            this.lbl10X5 = new System.Windows.Forms.Label();
            this.lbl10X4 = new System.Windows.Forms.Label();
            this.lbl10X3 = new System.Windows.Forms.Label();
            this.lbl10X2 = new System.Windows.Forms.Label();
            this.lbl10X1 = new System.Windows.Forms.Label();
            this.lbl9X10 = new System.Windows.Forms.Label();
            this.lbl9X7 = new System.Windows.Forms.Label();
            this.lbl9X9 = new System.Windows.Forms.Label();
            this.lbl9X8 = new System.Windows.Forms.Label();
            this.lbl9X6 = new System.Windows.Forms.Label();
            this.lbl9X5 = new System.Windows.Forms.Label();
            this.lbl9X4 = new System.Windows.Forms.Label();
            this.lbl9X3 = new System.Windows.Forms.Label();
            this.lbl9X2 = new System.Windows.Forms.Label();
            this.lbl9X1 = new System.Windows.Forms.Label();
            this.lbl8X10 = new System.Windows.Forms.Label();
            this.lbl8X7 = new System.Windows.Forms.Label();
            this.lbl8X9 = new System.Windows.Forms.Label();
            this.lbl8X8 = new System.Windows.Forms.Label();
            this.lbl8X6 = new System.Windows.Forms.Label();
            this.lbl8X5 = new System.Windows.Forms.Label();
            this.lbl8X4 = new System.Windows.Forms.Label();
            this.lbl8X3 = new System.Windows.Forms.Label();
            this.lbl8X2 = new System.Windows.Forms.Label();
            this.lbl8X1 = new System.Windows.Forms.Label();
            this.lbl7X10 = new System.Windows.Forms.Label();
            this.lbl7X7 = new System.Windows.Forms.Label();
            this.lbl7X9 = new System.Windows.Forms.Label();
            this.lbl7X8 = new System.Windows.Forms.Label();
            this.lbl7X6 = new System.Windows.Forms.Label();
            this.lbl7X5 = new System.Windows.Forms.Label();
            this.lbl7X4 = new System.Windows.Forms.Label();
            this.lbl7X3 = new System.Windows.Forms.Label();
            this.lbl7X2 = new System.Windows.Forms.Label();
            this.lbl7X1 = new System.Windows.Forms.Label();
            this.lbl6X10 = new System.Windows.Forms.Label();
            this.lbl6X7 = new System.Windows.Forms.Label();
            this.lbl6X9 = new System.Windows.Forms.Label();
            this.lbl6X8 = new System.Windows.Forms.Label();
            this.lbl6X6 = new System.Windows.Forms.Label();
            this.lbl6X5 = new System.Windows.Forms.Label();
            this.lbl6X4 = new System.Windows.Forms.Label();
            this.lbl6X3 = new System.Windows.Forms.Label();
            this.lbl6X2 = new System.Windows.Forms.Label();
            this.lbl6X1 = new System.Windows.Forms.Label();
            this.lbl5X10 = new System.Windows.Forms.Label();
            this.lbl5X7 = new System.Windows.Forms.Label();
            this.lbl5X9 = new System.Windows.Forms.Label();
            this.lbl5X8 = new System.Windows.Forms.Label();
            this.lbl5X6 = new System.Windows.Forms.Label();
            this.lbl5X5 = new System.Windows.Forms.Label();
            this.lbl5X4 = new System.Windows.Forms.Label();
            this.lbl5X3 = new System.Windows.Forms.Label();
            this.lbl5X2 = new System.Windows.Forms.Label();
            this.lbl5X1 = new System.Windows.Forms.Label();
            this.lbl4X10 = new System.Windows.Forms.Label();
            this.lbl4X7 = new System.Windows.Forms.Label();
            this.lbl4X9 = new System.Windows.Forms.Label();
            this.lbl4X8 = new System.Windows.Forms.Label();
            this.lbl4X6 = new System.Windows.Forms.Label();
            this.lbl4X5 = new System.Windows.Forms.Label();
            this.lbl4X4 = new System.Windows.Forms.Label();
            this.lbl4X3 = new System.Windows.Forms.Label();
            this.lbl4X2 = new System.Windows.Forms.Label();
            this.lbl4X1 = new System.Windows.Forms.Label();
            this.lbl3X10 = new System.Windows.Forms.Label();
            this.lbl3X7 = new System.Windows.Forms.Label();
            this.lbl3X9 = new System.Windows.Forms.Label();
            this.lbl3X8 = new System.Windows.Forms.Label();
            this.lbl3X6 = new System.Windows.Forms.Label();
            this.lbl3X5 = new System.Windows.Forms.Label();
            this.lbl3X4 = new System.Windows.Forms.Label();
            this.lbl3X3 = new System.Windows.Forms.Label();
            this.lbl3X2 = new System.Windows.Forms.Label();
            this.lbl3X1 = new System.Windows.Forms.Label();
            this.lbl2X10 = new System.Windows.Forms.Label();
            this.lbl2X7 = new System.Windows.Forms.Label();
            this.lbl2X9 = new System.Windows.Forms.Label();
            this.lbl2X8 = new System.Windows.Forms.Label();
            this.lbl2X6 = new System.Windows.Forms.Label();
            this.lbl2X5 = new System.Windows.Forms.Label();
            this.lbl2X4 = new System.Windows.Forms.Label();
            this.lbl2X3 = new System.Windows.Forms.Label();
            this.lbl2X2 = new System.Windows.Forms.Label();
            this.lbl2X1 = new System.Windows.Forms.Label();
            this.lbl1X10 = new System.Windows.Forms.Label();
            this.lbl1X7 = new System.Windows.Forms.Label();
            this.lbl1X9 = new System.Windows.Forms.Label();
            this.lbl1X8 = new System.Windows.Forms.Label();
            this.lbl1X6 = new System.Windows.Forms.Label();
            this.lbl1X5 = new System.Windows.Forms.Label();
            this.lbl1X4 = new System.Windows.Forms.Label();
            this.lbl1X3 = new System.Windows.Forms.Label();
            this.lbl1X2 = new System.Windows.Forms.Label();
            this.lbl1X1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Location = new System.Drawing.Point(81, 67);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 173);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seleccionar";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 36);
            this.button1.TabIndex = 1;
            this.button1.Text = "Seleccionar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sumatoria",
            "Tablas de Multiplicar",
            "Numero perfecto"});
            this.comboBox1.Location = new System.Drawing.Point(23, 35);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(166, 24);
            this.comboBox1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(447, 58);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(831, 696);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(769, 603);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sumatoria";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(391, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(332, 216);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 36);
            this.button2.TabIndex = 3;
            this.button2.Text = "calcular";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(332, 142);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 22);
            this.textBox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(221, 293);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Resultado";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(208, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese un numero";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.lbl10X10);
            this.tabPage2.Controls.Add(this.lbl10X7);
            this.tabPage2.Controls.Add(this.lbl10X9);
            this.tabPage2.Controls.Add(this.lbl10X8);
            this.tabPage2.Controls.Add(this.lbl10X6);
            this.tabPage2.Controls.Add(this.lbl10X5);
            this.tabPage2.Controls.Add(this.lbl10X4);
            this.tabPage2.Controls.Add(this.lbl10X3);
            this.tabPage2.Controls.Add(this.lbl10X2);
            this.tabPage2.Controls.Add(this.lbl10X1);
            this.tabPage2.Controls.Add(this.lbl9X10);
            this.tabPage2.Controls.Add(this.lbl9X7);
            this.tabPage2.Controls.Add(this.lbl9X9);
            this.tabPage2.Controls.Add(this.lbl9X8);
            this.tabPage2.Controls.Add(this.lbl9X6);
            this.tabPage2.Controls.Add(this.lbl9X5);
            this.tabPage2.Controls.Add(this.lbl9X4);
            this.tabPage2.Controls.Add(this.lbl9X3);
            this.tabPage2.Controls.Add(this.lbl9X2);
            this.tabPage2.Controls.Add(this.lbl9X1);
            this.tabPage2.Controls.Add(this.lbl8X10);
            this.tabPage2.Controls.Add(this.lbl8X7);
            this.tabPage2.Controls.Add(this.lbl8X9);
            this.tabPage2.Controls.Add(this.lbl8X8);
            this.tabPage2.Controls.Add(this.lbl8X6);
            this.tabPage2.Controls.Add(this.lbl8X5);
            this.tabPage2.Controls.Add(this.lbl8X4);
            this.tabPage2.Controls.Add(this.lbl8X3);
            this.tabPage2.Controls.Add(this.lbl8X2);
            this.tabPage2.Controls.Add(this.lbl8X1);
            this.tabPage2.Controls.Add(this.lbl7X10);
            this.tabPage2.Controls.Add(this.lbl7X7);
            this.tabPage2.Controls.Add(this.lbl7X9);
            this.tabPage2.Controls.Add(this.lbl7X8);
            this.tabPage2.Controls.Add(this.lbl7X6);
            this.tabPage2.Controls.Add(this.lbl7X5);
            this.tabPage2.Controls.Add(this.lbl7X4);
            this.tabPage2.Controls.Add(this.lbl7X3);
            this.tabPage2.Controls.Add(this.lbl7X2);
            this.tabPage2.Controls.Add(this.lbl7X1);
            this.tabPage2.Controls.Add(this.lbl6X10);
            this.tabPage2.Controls.Add(this.lbl6X7);
            this.tabPage2.Controls.Add(this.lbl6X9);
            this.tabPage2.Controls.Add(this.lbl6X8);
            this.tabPage2.Controls.Add(this.lbl6X6);
            this.tabPage2.Controls.Add(this.lbl6X5);
            this.tabPage2.Controls.Add(this.lbl6X4);
            this.tabPage2.Controls.Add(this.lbl6X3);
            this.tabPage2.Controls.Add(this.lbl6X2);
            this.tabPage2.Controls.Add(this.lbl6X1);
            this.tabPage2.Controls.Add(this.lbl5X10);
            this.tabPage2.Controls.Add(this.lbl5X7);
            this.tabPage2.Controls.Add(this.lbl5X9);
            this.tabPage2.Controls.Add(this.lbl5X8);
            this.tabPage2.Controls.Add(this.lbl5X6);
            this.tabPage2.Controls.Add(this.lbl5X5);
            this.tabPage2.Controls.Add(this.lbl5X4);
            this.tabPage2.Controls.Add(this.lbl5X3);
            this.tabPage2.Controls.Add(this.lbl5X2);
            this.tabPage2.Controls.Add(this.lbl5X1);
            this.tabPage2.Controls.Add(this.lbl4X10);
            this.tabPage2.Controls.Add(this.lbl4X7);
            this.tabPage2.Controls.Add(this.lbl4X9);
            this.tabPage2.Controls.Add(this.lbl4X8);
            this.tabPage2.Controls.Add(this.lbl4X6);
            this.tabPage2.Controls.Add(this.lbl4X5);
            this.tabPage2.Controls.Add(this.lbl4X4);
            this.tabPage2.Controls.Add(this.lbl4X3);
            this.tabPage2.Controls.Add(this.lbl4X2);
            this.tabPage2.Controls.Add(this.lbl4X1);
            this.tabPage2.Controls.Add(this.lbl3X10);
            this.tabPage2.Controls.Add(this.lbl3X7);
            this.tabPage2.Controls.Add(this.lbl3X9);
            this.tabPage2.Controls.Add(this.lbl3X8);
            this.tabPage2.Controls.Add(this.lbl3X6);
            this.tabPage2.Controls.Add(this.lbl3X5);
            this.tabPage2.Controls.Add(this.lbl3X4);
            this.tabPage2.Controls.Add(this.lbl3X3);
            this.tabPage2.Controls.Add(this.lbl3X2);
            this.tabPage2.Controls.Add(this.lbl3X1);
            this.tabPage2.Controls.Add(this.lbl2X10);
            this.tabPage2.Controls.Add(this.lbl2X7);
            this.tabPage2.Controls.Add(this.lbl2X9);
            this.tabPage2.Controls.Add(this.lbl2X8);
            this.tabPage2.Controls.Add(this.lbl2X6);
            this.tabPage2.Controls.Add(this.lbl2X5);
            this.tabPage2.Controls.Add(this.lbl2X4);
            this.tabPage2.Controls.Add(this.lbl2X3);
            this.tabPage2.Controls.Add(this.lbl2X2);
            this.tabPage2.Controls.Add(this.lbl2X1);
            this.tabPage2.Controls.Add(this.lbl1X10);
            this.tabPage2.Controls.Add(this.lbl1X7);
            this.tabPage2.Controls.Add(this.lbl1X9);
            this.tabPage2.Controls.Add(this.lbl1X8);
            this.tabPage2.Controls.Add(this.lbl1X6);
            this.tabPage2.Controls.Add(this.lbl1X5);
            this.tabPage2.Controls.Add(this.lbl1X4);
            this.tabPage2.Controls.Add(this.lbl1X3);
            this.tabPage2.Controls.Add(this.lbl1X2);
            this.tabPage2.Controls.Add(this.lbl1X1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(823, 667);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tablas de multiplicar";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbl10X10
            // 
            this.lbl10X10.AutoSize = true;
            this.lbl10X10.Location = new System.Drawing.Point(744, 587);
            this.lbl10X10.Name = "lbl10X10";
            this.lbl10X10.Size = new System.Drawing.Size(51, 16);
            this.lbl10X10.TabIndex = 99;
            this.lbl10X10.Text = "label97";
            // 
            // lbl10X7
            // 
            this.lbl10X7.AutoSize = true;
            this.lbl10X7.Location = new System.Drawing.Point(530, 587);
            this.lbl10X7.Name = "lbl10X7";
            this.lbl10X7.Size = new System.Drawing.Size(51, 16);
            this.lbl10X7.TabIndex = 98;
            this.lbl10X7.Text = "label98";
            // 
            // lbl10X9
            // 
            this.lbl10X9.AutoSize = true;
            this.lbl10X9.Location = new System.Drawing.Point(673, 587);
            this.lbl10X9.Name = "lbl10X9";
            this.lbl10X9.Size = new System.Drawing.Size(51, 16);
            this.lbl10X9.TabIndex = 97;
            this.lbl10X9.Text = "label99";
            // 
            // lbl10X8
            // 
            this.lbl10X8.AutoSize = true;
            this.lbl10X8.Location = new System.Drawing.Point(605, 587);
            this.lbl10X8.Name = "lbl10X8";
            this.lbl10X8.Size = new System.Drawing.Size(58, 16);
            this.lbl10X8.TabIndex = 96;
            this.lbl10X8.Text = "label100";
            // 
            // lbl10X6
            // 
            this.lbl10X6.AutoSize = true;
            this.lbl10X6.Location = new System.Drawing.Point(460, 587);
            this.lbl10X6.Name = "lbl10X6";
            this.lbl10X6.Size = new System.Drawing.Size(58, 16);
            this.lbl10X6.TabIndex = 95;
            this.lbl10X6.Text = "label101";
            // 
            // lbl10X5
            // 
            this.lbl10X5.AutoSize = true;
            this.lbl10X5.Location = new System.Drawing.Point(392, 587);
            this.lbl10X5.Name = "lbl10X5";
            this.lbl10X5.Size = new System.Drawing.Size(58, 16);
            this.lbl10X5.TabIndex = 94;
            this.lbl10X5.Text = "label102";
            // 
            // lbl10X4
            // 
            this.lbl10X4.AutoSize = true;
            this.lbl10X4.Location = new System.Drawing.Point(320, 587);
            this.lbl10X4.Name = "lbl10X4";
            this.lbl10X4.Size = new System.Drawing.Size(58, 16);
            this.lbl10X4.TabIndex = 93;
            this.lbl10X4.Text = "label103";
            // 
            // lbl10X3
            // 
            this.lbl10X3.AutoSize = true;
            this.lbl10X3.Location = new System.Drawing.Point(249, 587);
            this.lbl10X3.Name = "lbl10X3";
            this.lbl10X3.Size = new System.Drawing.Size(58, 16);
            this.lbl10X3.TabIndex = 92;
            this.lbl10X3.Text = "label104";
            // 
            // lbl10X2
            // 
            this.lbl10X2.AutoSize = true;
            this.lbl10X2.Location = new System.Drawing.Point(171, 587);
            this.lbl10X2.Name = "lbl10X2";
            this.lbl10X2.Size = new System.Drawing.Size(58, 16);
            this.lbl10X2.TabIndex = 91;
            this.lbl10X2.Text = "label105";
            // 
            // lbl10X1
            // 
            this.lbl10X1.AutoSize = true;
            this.lbl10X1.Location = new System.Drawing.Point(96, 587);
            this.lbl10X1.Name = "lbl10X1";
            this.lbl10X1.Size = new System.Drawing.Size(58, 16);
            this.lbl10X1.TabIndex = 90;
            this.lbl10X1.Text = "label106";
            // 
            // lbl9X10
            // 
            this.lbl9X10.AutoSize = true;
            this.lbl9X10.Location = new System.Drawing.Point(744, 527);
            this.lbl9X10.Name = "lbl9X10";
            this.lbl9X10.Size = new System.Drawing.Size(51, 16);
            this.lbl9X10.TabIndex = 89;
            this.lbl9X10.Text = "label87";
            // 
            // lbl9X7
            // 
            this.lbl9X7.AutoSize = true;
            this.lbl9X7.Location = new System.Drawing.Point(530, 527);
            this.lbl9X7.Name = "lbl9X7";
            this.lbl9X7.Size = new System.Drawing.Size(51, 16);
            this.lbl9X7.TabIndex = 88;
            this.lbl9X7.Text = "label88";
            // 
            // lbl9X9
            // 
            this.lbl9X9.AutoSize = true;
            this.lbl9X9.Location = new System.Drawing.Point(673, 527);
            this.lbl9X9.Name = "lbl9X9";
            this.lbl9X9.Size = new System.Drawing.Size(51, 16);
            this.lbl9X9.TabIndex = 87;
            this.lbl9X9.Text = "label89";
            // 
            // lbl9X8
            // 
            this.lbl9X8.AutoSize = true;
            this.lbl9X8.Location = new System.Drawing.Point(605, 527);
            this.lbl9X8.Name = "lbl9X8";
            this.lbl9X8.Size = new System.Drawing.Size(51, 16);
            this.lbl9X8.TabIndex = 86;
            this.lbl9X8.Text = "label90";
            // 
            // lbl9X6
            // 
            this.lbl9X6.AutoSize = true;
            this.lbl9X6.Location = new System.Drawing.Point(460, 527);
            this.lbl9X6.Name = "lbl9X6";
            this.lbl9X6.Size = new System.Drawing.Size(51, 16);
            this.lbl9X6.TabIndex = 85;
            this.lbl9X6.Text = "label91";
            // 
            // lbl9X5
            // 
            this.lbl9X5.AutoSize = true;
            this.lbl9X5.Location = new System.Drawing.Point(392, 527);
            this.lbl9X5.Name = "lbl9X5";
            this.lbl9X5.Size = new System.Drawing.Size(51, 16);
            this.lbl9X5.TabIndex = 84;
            this.lbl9X5.Text = "label92";
            // 
            // lbl9X4
            // 
            this.lbl9X4.AutoSize = true;
            this.lbl9X4.Location = new System.Drawing.Point(320, 527);
            this.lbl9X4.Name = "lbl9X4";
            this.lbl9X4.Size = new System.Drawing.Size(51, 16);
            this.lbl9X4.TabIndex = 83;
            this.lbl9X4.Text = "label93";
            // 
            // lbl9X3
            // 
            this.lbl9X3.AutoSize = true;
            this.lbl9X3.Location = new System.Drawing.Point(249, 527);
            this.lbl9X3.Name = "lbl9X3";
            this.lbl9X3.Size = new System.Drawing.Size(51, 16);
            this.lbl9X3.TabIndex = 82;
            this.lbl9X3.Text = "label94";
            // 
            // lbl9X2
            // 
            this.lbl9X2.AutoSize = true;
            this.lbl9X2.Location = new System.Drawing.Point(171, 527);
            this.lbl9X2.Name = "lbl9X2";
            this.lbl9X2.Size = new System.Drawing.Size(51, 16);
            this.lbl9X2.TabIndex = 81;
            this.lbl9X2.Text = "label95";
            // 
            // lbl9X1
            // 
            this.lbl9X1.AutoSize = true;
            this.lbl9X1.Location = new System.Drawing.Point(96, 527);
            this.lbl9X1.Name = "lbl9X1";
            this.lbl9X1.Size = new System.Drawing.Size(51, 16);
            this.lbl9X1.TabIndex = 80;
            this.lbl9X1.Text = "label96";
            // 
            // lbl8X10
            // 
            this.lbl8X10.AutoSize = true;
            this.lbl8X10.Location = new System.Drawing.Point(744, 480);
            this.lbl8X10.Name = "lbl8X10";
            this.lbl8X10.Size = new System.Drawing.Size(51, 16);
            this.lbl8X10.TabIndex = 79;
            this.lbl8X10.Text = "label77";
            // 
            // lbl8X7
            // 
            this.lbl8X7.AutoSize = true;
            this.lbl8X7.Location = new System.Drawing.Point(530, 480);
            this.lbl8X7.Name = "lbl8X7";
            this.lbl8X7.Size = new System.Drawing.Size(51, 16);
            this.lbl8X7.TabIndex = 78;
            this.lbl8X7.Text = "label78";
            // 
            // lbl8X9
            // 
            this.lbl8X9.AutoSize = true;
            this.lbl8X9.Location = new System.Drawing.Point(673, 480);
            this.lbl8X9.Name = "lbl8X9";
            this.lbl8X9.Size = new System.Drawing.Size(51, 16);
            this.lbl8X9.TabIndex = 77;
            this.lbl8X9.Text = "label79";
            // 
            // lbl8X8
            // 
            this.lbl8X8.AutoSize = true;
            this.lbl8X8.Location = new System.Drawing.Point(605, 480);
            this.lbl8X8.Name = "lbl8X8";
            this.lbl8X8.Size = new System.Drawing.Size(51, 16);
            this.lbl8X8.TabIndex = 76;
            this.lbl8X8.Text = "label80";
            // 
            // lbl8X6
            // 
            this.lbl8X6.AutoSize = true;
            this.lbl8X6.Location = new System.Drawing.Point(460, 480);
            this.lbl8X6.Name = "lbl8X6";
            this.lbl8X6.Size = new System.Drawing.Size(51, 16);
            this.lbl8X6.TabIndex = 75;
            this.lbl8X6.Text = "label81";
            // 
            // lbl8X5
            // 
            this.lbl8X5.AutoSize = true;
            this.lbl8X5.Location = new System.Drawing.Point(392, 480);
            this.lbl8X5.Name = "lbl8X5";
            this.lbl8X5.Size = new System.Drawing.Size(51, 16);
            this.lbl8X5.TabIndex = 74;
            this.lbl8X5.Text = "label82";
            // 
            // lbl8X4
            // 
            this.lbl8X4.AutoSize = true;
            this.lbl8X4.Location = new System.Drawing.Point(320, 480);
            this.lbl8X4.Name = "lbl8X4";
            this.lbl8X4.Size = new System.Drawing.Size(51, 16);
            this.lbl8X4.TabIndex = 73;
            this.lbl8X4.Text = "label83";
            // 
            // lbl8X3
            // 
            this.lbl8X3.AutoSize = true;
            this.lbl8X3.Location = new System.Drawing.Point(249, 480);
            this.lbl8X3.Name = "lbl8X3";
            this.lbl8X3.Size = new System.Drawing.Size(51, 16);
            this.lbl8X3.TabIndex = 72;
            this.lbl8X3.Text = "label84";
            // 
            // lbl8X2
            // 
            this.lbl8X2.AutoSize = true;
            this.lbl8X2.Location = new System.Drawing.Point(171, 480);
            this.lbl8X2.Name = "lbl8X2";
            this.lbl8X2.Size = new System.Drawing.Size(51, 16);
            this.lbl8X2.TabIndex = 71;
            this.lbl8X2.Text = "label85";
            // 
            // lbl8X1
            // 
            this.lbl8X1.AutoSize = true;
            this.lbl8X1.Location = new System.Drawing.Point(96, 480);
            this.lbl8X1.Name = "lbl8X1";
            this.lbl8X1.Size = new System.Drawing.Size(51, 16);
            this.lbl8X1.TabIndex = 70;
            this.lbl8X1.Text = "label86";
            // 
            // lbl7X10
            // 
            this.lbl7X10.AutoSize = true;
            this.lbl7X10.Location = new System.Drawing.Point(744, 425);
            this.lbl7X10.Name = "lbl7X10";
            this.lbl7X10.Size = new System.Drawing.Size(51, 16);
            this.lbl7X10.TabIndex = 69;
            this.lbl7X10.Text = "label67";
            // 
            // lbl7X7
            // 
            this.lbl7X7.AutoSize = true;
            this.lbl7X7.Location = new System.Drawing.Point(530, 425);
            this.lbl7X7.Name = "lbl7X7";
            this.lbl7X7.Size = new System.Drawing.Size(51, 16);
            this.lbl7X7.TabIndex = 68;
            this.lbl7X7.Text = "label68";
            // 
            // lbl7X9
            // 
            this.lbl7X9.AutoSize = true;
            this.lbl7X9.Location = new System.Drawing.Point(673, 425);
            this.lbl7X9.Name = "lbl7X9";
            this.lbl7X9.Size = new System.Drawing.Size(51, 16);
            this.lbl7X9.TabIndex = 67;
            this.lbl7X9.Text = "label69";
            // 
            // lbl7X8
            // 
            this.lbl7X8.AutoSize = true;
            this.lbl7X8.Location = new System.Drawing.Point(605, 425);
            this.lbl7X8.Name = "lbl7X8";
            this.lbl7X8.Size = new System.Drawing.Size(51, 16);
            this.lbl7X8.TabIndex = 66;
            this.lbl7X8.Text = "label70";
            // 
            // lbl7X6
            // 
            this.lbl7X6.AutoSize = true;
            this.lbl7X6.Location = new System.Drawing.Point(460, 425);
            this.lbl7X6.Name = "lbl7X6";
            this.lbl7X6.Size = new System.Drawing.Size(51, 16);
            this.lbl7X6.TabIndex = 65;
            this.lbl7X6.Text = "label71";
            // 
            // lbl7X5
            // 
            this.lbl7X5.AutoSize = true;
            this.lbl7X5.Location = new System.Drawing.Point(392, 425);
            this.lbl7X5.Name = "lbl7X5";
            this.lbl7X5.Size = new System.Drawing.Size(51, 16);
            this.lbl7X5.TabIndex = 64;
            this.lbl7X5.Text = "label72";
            // 
            // lbl7X4
            // 
            this.lbl7X4.AutoSize = true;
            this.lbl7X4.Location = new System.Drawing.Point(320, 425);
            this.lbl7X4.Name = "lbl7X4";
            this.lbl7X4.Size = new System.Drawing.Size(51, 16);
            this.lbl7X4.TabIndex = 63;
            this.lbl7X4.Text = "label73";
            // 
            // lbl7X3
            // 
            this.lbl7X3.AutoSize = true;
            this.lbl7X3.Location = new System.Drawing.Point(249, 425);
            this.lbl7X3.Name = "lbl7X3";
            this.lbl7X3.Size = new System.Drawing.Size(51, 16);
            this.lbl7X3.TabIndex = 62;
            this.lbl7X3.Text = "label74";
            // 
            // lbl7X2
            // 
            this.lbl7X2.AutoSize = true;
            this.lbl7X2.Location = new System.Drawing.Point(171, 425);
            this.lbl7X2.Name = "lbl7X2";
            this.lbl7X2.Size = new System.Drawing.Size(51, 16);
            this.lbl7X2.TabIndex = 61;
            this.lbl7X2.Text = "label75";
            // 
            // lbl7X1
            // 
            this.lbl7X1.AutoSize = true;
            this.lbl7X1.Location = new System.Drawing.Point(96, 425);
            this.lbl7X1.Name = "lbl7X1";
            this.lbl7X1.Size = new System.Drawing.Size(51, 16);
            this.lbl7X1.TabIndex = 60;
            this.lbl7X1.Text = "label76";
            // 
            // lbl6X10
            // 
            this.lbl6X10.AutoSize = true;
            this.lbl6X10.Location = new System.Drawing.Point(744, 367);
            this.lbl6X10.Name = "lbl6X10";
            this.lbl6X10.Size = new System.Drawing.Size(51, 16);
            this.lbl6X10.TabIndex = 59;
            this.lbl6X10.Text = "label57";
            // 
            // lbl6X7
            // 
            this.lbl6X7.AutoSize = true;
            this.lbl6X7.Location = new System.Drawing.Point(530, 367);
            this.lbl6X7.Name = "lbl6X7";
            this.lbl6X7.Size = new System.Drawing.Size(51, 16);
            this.lbl6X7.TabIndex = 58;
            this.lbl6X7.Text = "label58";
            // 
            // lbl6X9
            // 
            this.lbl6X9.AutoSize = true;
            this.lbl6X9.Location = new System.Drawing.Point(673, 367);
            this.lbl6X9.Name = "lbl6X9";
            this.lbl6X9.Size = new System.Drawing.Size(51, 16);
            this.lbl6X9.TabIndex = 57;
            this.lbl6X9.Text = "label59";
            // 
            // lbl6X8
            // 
            this.lbl6X8.AutoSize = true;
            this.lbl6X8.Location = new System.Drawing.Point(605, 367);
            this.lbl6X8.Name = "lbl6X8";
            this.lbl6X8.Size = new System.Drawing.Size(51, 16);
            this.lbl6X8.TabIndex = 56;
            this.lbl6X8.Text = "label60";
            // 
            // lbl6X6
            // 
            this.lbl6X6.AutoSize = true;
            this.lbl6X6.Location = new System.Drawing.Point(460, 367);
            this.lbl6X6.Name = "lbl6X6";
            this.lbl6X6.Size = new System.Drawing.Size(51, 16);
            this.lbl6X6.TabIndex = 55;
            this.lbl6X6.Text = "label61";
            // 
            // lbl6X5
            // 
            this.lbl6X5.AutoSize = true;
            this.lbl6X5.Location = new System.Drawing.Point(392, 367);
            this.lbl6X5.Name = "lbl6X5";
            this.lbl6X5.Size = new System.Drawing.Size(51, 16);
            this.lbl6X5.TabIndex = 54;
            this.lbl6X5.Text = "label62";
            // 
            // lbl6X4
            // 
            this.lbl6X4.AutoSize = true;
            this.lbl6X4.Location = new System.Drawing.Point(320, 367);
            this.lbl6X4.Name = "lbl6X4";
            this.lbl6X4.Size = new System.Drawing.Size(51, 16);
            this.lbl6X4.TabIndex = 53;
            this.lbl6X4.Text = "label63";
            // 
            // lbl6X3
            // 
            this.lbl6X3.AutoSize = true;
            this.lbl6X3.Location = new System.Drawing.Point(249, 367);
            this.lbl6X3.Name = "lbl6X3";
            this.lbl6X3.Size = new System.Drawing.Size(51, 16);
            this.lbl6X3.TabIndex = 52;
            this.lbl6X3.Text = "label64";
            // 
            // lbl6X2
            // 
            this.lbl6X2.AutoSize = true;
            this.lbl6X2.Location = new System.Drawing.Point(171, 367);
            this.lbl6X2.Name = "lbl6X2";
            this.lbl6X2.Size = new System.Drawing.Size(51, 16);
            this.lbl6X2.TabIndex = 51;
            this.lbl6X2.Text = "label65";
            // 
            // lbl6X1
            // 
            this.lbl6X1.AutoSize = true;
            this.lbl6X1.Location = new System.Drawing.Point(96, 367);
            this.lbl6X1.Name = "lbl6X1";
            this.lbl6X1.Size = new System.Drawing.Size(51, 16);
            this.lbl6X1.TabIndex = 50;
            this.lbl6X1.Text = "label66";
            // 
            // lbl5X10
            // 
            this.lbl5X10.AutoSize = true;
            this.lbl5X10.Location = new System.Drawing.Point(744, 307);
            this.lbl5X10.Name = "lbl5X10";
            this.lbl5X10.Size = new System.Drawing.Size(51, 16);
            this.lbl5X10.TabIndex = 49;
            this.lbl5X10.Text = "label47";
            // 
            // lbl5X7
            // 
            this.lbl5X7.AutoSize = true;
            this.lbl5X7.Location = new System.Drawing.Point(530, 307);
            this.lbl5X7.Name = "lbl5X7";
            this.lbl5X7.Size = new System.Drawing.Size(51, 16);
            this.lbl5X7.TabIndex = 48;
            this.lbl5X7.Text = "label48";
            // 
            // lbl5X9
            // 
            this.lbl5X9.AutoSize = true;
            this.lbl5X9.Location = new System.Drawing.Point(673, 307);
            this.lbl5X9.Name = "lbl5X9";
            this.lbl5X9.Size = new System.Drawing.Size(51, 16);
            this.lbl5X9.TabIndex = 47;
            this.lbl5X9.Text = "label49";
            // 
            // lbl5X8
            // 
            this.lbl5X8.AutoSize = true;
            this.lbl5X8.Location = new System.Drawing.Point(605, 307);
            this.lbl5X8.Name = "lbl5X8";
            this.lbl5X8.Size = new System.Drawing.Size(51, 16);
            this.lbl5X8.TabIndex = 46;
            this.lbl5X8.Text = "label50";
            // 
            // lbl5X6
            // 
            this.lbl5X6.AutoSize = true;
            this.lbl5X6.Location = new System.Drawing.Point(460, 307);
            this.lbl5X6.Name = "lbl5X6";
            this.lbl5X6.Size = new System.Drawing.Size(51, 16);
            this.lbl5X6.TabIndex = 45;
            this.lbl5X6.Text = "label51";
            // 
            // lbl5X5
            // 
            this.lbl5X5.AutoSize = true;
            this.lbl5X5.Location = new System.Drawing.Point(398, 311);
            this.lbl5X5.Name = "lbl5X5";
            this.lbl5X5.Size = new System.Drawing.Size(51, 16);
            this.lbl5X5.TabIndex = 44;
            this.lbl5X5.Text = "label52";
            // 
            // lbl5X4
            // 
            this.lbl5X4.AutoSize = true;
            this.lbl5X4.Location = new System.Drawing.Point(320, 307);
            this.lbl5X4.Name = "lbl5X4";
            this.lbl5X4.Size = new System.Drawing.Size(51, 16);
            this.lbl5X4.TabIndex = 43;
            this.lbl5X4.Text = "label53";
            // 
            // lbl5X3
            // 
            this.lbl5X3.AutoSize = true;
            this.lbl5X3.Location = new System.Drawing.Point(249, 307);
            this.lbl5X3.Name = "lbl5X3";
            this.lbl5X3.Size = new System.Drawing.Size(51, 16);
            this.lbl5X3.TabIndex = 42;
            this.lbl5X3.Text = "label54";
            // 
            // lbl5X2
            // 
            this.lbl5X2.AutoSize = true;
            this.lbl5X2.Location = new System.Drawing.Point(171, 307);
            this.lbl5X2.Name = "lbl5X2";
            this.lbl5X2.Size = new System.Drawing.Size(51, 16);
            this.lbl5X2.TabIndex = 41;
            this.lbl5X2.Text = "label55";
            // 
            // lbl5X1
            // 
            this.lbl5X1.AutoSize = true;
            this.lbl5X1.Location = new System.Drawing.Point(96, 307);
            this.lbl5X1.Name = "lbl5X1";
            this.lbl5X1.Size = new System.Drawing.Size(51, 16);
            this.lbl5X1.TabIndex = 40;
            this.lbl5X1.Text = "label56";
            // 
            // lbl4X10
            // 
            this.lbl4X10.AutoSize = true;
            this.lbl4X10.Location = new System.Drawing.Point(744, 250);
            this.lbl4X10.Name = "lbl4X10";
            this.lbl4X10.Size = new System.Drawing.Size(51, 16);
            this.lbl4X10.TabIndex = 39;
            this.lbl4X10.Text = "label37";
            // 
            // lbl4X7
            // 
            this.lbl4X7.AutoSize = true;
            this.lbl4X7.Location = new System.Drawing.Point(530, 250);
            this.lbl4X7.Name = "lbl4X7";
            this.lbl4X7.Size = new System.Drawing.Size(51, 16);
            this.lbl4X7.TabIndex = 38;
            this.lbl4X7.Text = "label38";
            // 
            // lbl4X9
            // 
            this.lbl4X9.AutoSize = true;
            this.lbl4X9.Location = new System.Drawing.Point(673, 250);
            this.lbl4X9.Name = "lbl4X9";
            this.lbl4X9.Size = new System.Drawing.Size(51, 16);
            this.lbl4X9.TabIndex = 37;
            this.lbl4X9.Text = "label39";
            // 
            // lbl4X8
            // 
            this.lbl4X8.AutoSize = true;
            this.lbl4X8.Location = new System.Drawing.Point(605, 250);
            this.lbl4X8.Name = "lbl4X8";
            this.lbl4X8.Size = new System.Drawing.Size(51, 16);
            this.lbl4X8.TabIndex = 36;
            this.lbl4X8.Text = "label40";
            // 
            // lbl4X6
            // 
            this.lbl4X6.AutoSize = true;
            this.lbl4X6.Location = new System.Drawing.Point(460, 250);
            this.lbl4X6.Name = "lbl4X6";
            this.lbl4X6.Size = new System.Drawing.Size(51, 16);
            this.lbl4X6.TabIndex = 35;
            this.lbl4X6.Text = "label41";
            // 
            // lbl4X5
            // 
            this.lbl4X5.AutoSize = true;
            this.lbl4X5.Location = new System.Drawing.Point(392, 250);
            this.lbl4X5.Name = "lbl4X5";
            this.lbl4X5.Size = new System.Drawing.Size(51, 16);
            this.lbl4X5.TabIndex = 34;
            this.lbl4X5.Text = "label42";
            // 
            // lbl4X4
            // 
            this.lbl4X4.AutoSize = true;
            this.lbl4X4.Location = new System.Drawing.Point(320, 250);
            this.lbl4X4.Name = "lbl4X4";
            this.lbl4X4.Size = new System.Drawing.Size(51, 16);
            this.lbl4X4.TabIndex = 33;
            this.lbl4X4.Text = "label43";
            // 
            // lbl4X3
            // 
            this.lbl4X3.AutoSize = true;
            this.lbl4X3.Location = new System.Drawing.Point(249, 250);
            this.lbl4X3.Name = "lbl4X3";
            this.lbl4X3.Size = new System.Drawing.Size(51, 16);
            this.lbl4X3.TabIndex = 32;
            this.lbl4X3.Text = "label44";
            // 
            // lbl4X2
            // 
            this.lbl4X2.AutoSize = true;
            this.lbl4X2.Location = new System.Drawing.Point(171, 250);
            this.lbl4X2.Name = "lbl4X2";
            this.lbl4X2.Size = new System.Drawing.Size(51, 16);
            this.lbl4X2.TabIndex = 31;
            this.lbl4X2.Text = "label45";
            // 
            // lbl4X1
            // 
            this.lbl4X1.AutoSize = true;
            this.lbl4X1.Location = new System.Drawing.Point(96, 250);
            this.lbl4X1.Name = "lbl4X1";
            this.lbl4X1.Size = new System.Drawing.Size(51, 16);
            this.lbl4X1.TabIndex = 30;
            this.lbl4X1.Text = "label46";
            // 
            // lbl3X10
            // 
            this.lbl3X10.AutoSize = true;
            this.lbl3X10.Location = new System.Drawing.Point(744, 200);
            this.lbl3X10.Name = "lbl3X10";
            this.lbl3X10.Size = new System.Drawing.Size(51, 16);
            this.lbl3X10.TabIndex = 29;
            this.lbl3X10.Text = "label27";
            // 
            // lbl3X7
            // 
            this.lbl3X7.AutoSize = true;
            this.lbl3X7.Location = new System.Drawing.Point(530, 200);
            this.lbl3X7.Name = "lbl3X7";
            this.lbl3X7.Size = new System.Drawing.Size(51, 16);
            this.lbl3X7.TabIndex = 28;
            this.lbl3X7.Text = "label28";
            // 
            // lbl3X9
            // 
            this.lbl3X9.AutoSize = true;
            this.lbl3X9.Location = new System.Drawing.Point(673, 200);
            this.lbl3X9.Name = "lbl3X9";
            this.lbl3X9.Size = new System.Drawing.Size(51, 16);
            this.lbl3X9.TabIndex = 27;
            this.lbl3X9.Text = "label29";
            // 
            // lbl3X8
            // 
            this.lbl3X8.AutoSize = true;
            this.lbl3X8.Location = new System.Drawing.Point(605, 200);
            this.lbl3X8.Name = "lbl3X8";
            this.lbl3X8.Size = new System.Drawing.Size(51, 16);
            this.lbl3X8.TabIndex = 26;
            this.lbl3X8.Text = "label30";
            // 
            // lbl3X6
            // 
            this.lbl3X6.AutoSize = true;
            this.lbl3X6.Location = new System.Drawing.Point(460, 200);
            this.lbl3X6.Name = "lbl3X6";
            this.lbl3X6.Size = new System.Drawing.Size(51, 16);
            this.lbl3X6.TabIndex = 25;
            this.lbl3X6.Text = "label31";
            // 
            // lbl3X5
            // 
            this.lbl3X5.AutoSize = true;
            this.lbl3X5.Location = new System.Drawing.Point(392, 200);
            this.lbl3X5.Name = "lbl3X5";
            this.lbl3X5.Size = new System.Drawing.Size(51, 16);
            this.lbl3X5.TabIndex = 24;
            this.lbl3X5.Text = "label32";
            // 
            // lbl3X4
            // 
            this.lbl3X4.AutoSize = true;
            this.lbl3X4.Location = new System.Drawing.Point(320, 200);
            this.lbl3X4.Name = "lbl3X4";
            this.lbl3X4.Size = new System.Drawing.Size(51, 16);
            this.lbl3X4.TabIndex = 23;
            this.lbl3X4.Text = "label33";
            // 
            // lbl3X3
            // 
            this.lbl3X3.AutoSize = true;
            this.lbl3X3.Location = new System.Drawing.Point(249, 200);
            this.lbl3X3.Name = "lbl3X3";
            this.lbl3X3.Size = new System.Drawing.Size(51, 16);
            this.lbl3X3.TabIndex = 22;
            this.lbl3X3.Text = "label34";
            // 
            // lbl3X2
            // 
            this.lbl3X2.AutoSize = true;
            this.lbl3X2.Location = new System.Drawing.Point(171, 200);
            this.lbl3X2.Name = "lbl3X2";
            this.lbl3X2.Size = new System.Drawing.Size(51, 16);
            this.lbl3X2.TabIndex = 21;
            this.lbl3X2.Text = "label35";
            // 
            // lbl3X1
            // 
            this.lbl3X1.AutoSize = true;
            this.lbl3X1.Location = new System.Drawing.Point(96, 200);
            this.lbl3X1.Name = "lbl3X1";
            this.lbl3X1.Size = new System.Drawing.Size(51, 16);
            this.lbl3X1.TabIndex = 20;
            this.lbl3X1.Text = "label36";
            // 
            // lbl2X10
            // 
            this.lbl2X10.AutoSize = true;
            this.lbl2X10.Location = new System.Drawing.Point(744, 155);
            this.lbl2X10.Name = "lbl2X10";
            this.lbl2X10.Size = new System.Drawing.Size(51, 16);
            this.lbl2X10.TabIndex = 19;
            this.lbl2X10.Text = "label17";
            // 
            // lbl2X7
            // 
            this.lbl2X7.AutoSize = true;
            this.lbl2X7.Location = new System.Drawing.Point(530, 155);
            this.lbl2X7.Name = "lbl2X7";
            this.lbl2X7.Size = new System.Drawing.Size(51, 16);
            this.lbl2X7.TabIndex = 18;
            this.lbl2X7.Text = "label18";
            // 
            // lbl2X9
            // 
            this.lbl2X9.AutoSize = true;
            this.lbl2X9.Location = new System.Drawing.Point(673, 155);
            this.lbl2X9.Name = "lbl2X9";
            this.lbl2X9.Size = new System.Drawing.Size(51, 16);
            this.lbl2X9.TabIndex = 17;
            this.lbl2X9.Text = "label19";
            // 
            // lbl2X8
            // 
            this.lbl2X8.AutoSize = true;
            this.lbl2X8.Location = new System.Drawing.Point(605, 155);
            this.lbl2X8.Name = "lbl2X8";
            this.lbl2X8.Size = new System.Drawing.Size(51, 16);
            this.lbl2X8.TabIndex = 16;
            this.lbl2X8.Text = "label20";
            // 
            // lbl2X6
            // 
            this.lbl2X6.AutoSize = true;
            this.lbl2X6.Location = new System.Drawing.Point(460, 155);
            this.lbl2X6.Name = "lbl2X6";
            this.lbl2X6.Size = new System.Drawing.Size(51, 16);
            this.lbl2X6.TabIndex = 15;
            this.lbl2X6.Text = "label21";
            // 
            // lbl2X5
            // 
            this.lbl2X5.AutoSize = true;
            this.lbl2X5.Location = new System.Drawing.Point(392, 155);
            this.lbl2X5.Name = "lbl2X5";
            this.lbl2X5.Size = new System.Drawing.Size(51, 16);
            this.lbl2X5.TabIndex = 14;
            this.lbl2X5.Text = "label22";
            // 
            // lbl2X4
            // 
            this.lbl2X4.AutoSize = true;
            this.lbl2X4.Location = new System.Drawing.Point(320, 155);
            this.lbl2X4.Name = "lbl2X4";
            this.lbl2X4.Size = new System.Drawing.Size(51, 16);
            this.lbl2X4.TabIndex = 13;
            this.lbl2X4.Text = "label23";
            // 
            // lbl2X3
            // 
            this.lbl2X3.AutoSize = true;
            this.lbl2X3.Location = new System.Drawing.Point(249, 155);
            this.lbl2X3.Name = "lbl2X3";
            this.lbl2X3.Size = new System.Drawing.Size(51, 16);
            this.lbl2X3.TabIndex = 12;
            this.lbl2X3.Text = "label24";
            // 
            // lbl2X2
            // 
            this.lbl2X2.AutoSize = true;
            this.lbl2X2.Location = new System.Drawing.Point(171, 155);
            this.lbl2X2.Name = "lbl2X2";
            this.lbl2X2.Size = new System.Drawing.Size(51, 16);
            this.lbl2X2.TabIndex = 11;
            this.lbl2X2.Text = "label25";
            // 
            // lbl2X1
            // 
            this.lbl2X1.AutoSize = true;
            this.lbl2X1.Location = new System.Drawing.Point(96, 155);
            this.lbl2X1.Name = "lbl2X1";
            this.lbl2X1.Size = new System.Drawing.Size(51, 16);
            this.lbl2X1.TabIndex = 10;
            this.lbl2X1.Text = "label26";
            // 
            // lbl1X10
            // 
            this.lbl1X10.AutoSize = true;
            this.lbl1X10.Location = new System.Drawing.Point(744, 111);
            this.lbl1X10.Name = "lbl1X10";
            this.lbl1X10.Size = new System.Drawing.Size(51, 16);
            this.lbl1X10.TabIndex = 9;
            this.lbl1X10.Text = "label16";
            // 
            // lbl1X7
            // 
            this.lbl1X7.AutoSize = true;
            this.lbl1X7.Location = new System.Drawing.Point(530, 111);
            this.lbl1X7.Name = "lbl1X7";
            this.lbl1X7.Size = new System.Drawing.Size(51, 16);
            this.lbl1X7.TabIndex = 8;
            this.lbl1X7.Text = "label15";
            // 
            // lbl1X9
            // 
            this.lbl1X9.AutoSize = true;
            this.lbl1X9.Location = new System.Drawing.Point(673, 111);
            this.lbl1X9.Name = "lbl1X9";
            this.lbl1X9.Size = new System.Drawing.Size(51, 16);
            this.lbl1X9.TabIndex = 7;
            this.lbl1X9.Text = "label14";
            // 
            // lbl1X8
            // 
            this.lbl1X8.AutoSize = true;
            this.lbl1X8.Location = new System.Drawing.Point(605, 111);
            this.lbl1X8.Name = "lbl1X8";
            this.lbl1X8.Size = new System.Drawing.Size(51, 16);
            this.lbl1X8.TabIndex = 6;
            this.lbl1X8.Text = "label13";
            // 
            // lbl1X6
            // 
            this.lbl1X6.AutoSize = true;
            this.lbl1X6.Location = new System.Drawing.Point(460, 111);
            this.lbl1X6.Name = "lbl1X6";
            this.lbl1X6.Size = new System.Drawing.Size(51, 16);
            this.lbl1X6.TabIndex = 5;
            this.lbl1X6.Text = "label12";
            // 
            // lbl1X5
            // 
            this.lbl1X5.AutoSize = true;
            this.lbl1X5.Location = new System.Drawing.Point(392, 111);
            this.lbl1X5.Name = "lbl1X5";
            this.lbl1X5.Size = new System.Drawing.Size(51, 16);
            this.lbl1X5.TabIndex = 4;
            this.lbl1X5.Text = "label11";
            // 
            // lbl1X4
            // 
            this.lbl1X4.AutoSize = true;
            this.lbl1X4.Location = new System.Drawing.Point(320, 111);
            this.lbl1X4.Name = "lbl1X4";
            this.lbl1X4.Size = new System.Drawing.Size(51, 16);
            this.lbl1X4.TabIndex = 3;
            this.lbl1X4.Text = "label10";
            // 
            // lbl1X3
            // 
            this.lbl1X3.AutoSize = true;
            this.lbl1X3.Location = new System.Drawing.Point(249, 111);
            this.lbl1X3.Name = "lbl1X3";
            this.lbl1X3.Size = new System.Drawing.Size(44, 16);
            this.lbl1X3.TabIndex = 2;
            this.lbl1X3.Text = "label9";
            // 
            // lbl1X2
            // 
            this.lbl1X2.AutoSize = true;
            this.lbl1X2.Location = new System.Drawing.Point(171, 111);
            this.lbl1X2.Name = "lbl1X2";
            this.lbl1X2.Size = new System.Drawing.Size(44, 16);
            this.lbl1X2.TabIndex = 1;
            this.lbl1X2.Text = "label8";
            // 
            // lbl1X1
            // 
            this.lbl1X1.AutoSize = true;
            this.lbl1X1.Location = new System.Drawing.Point(96, 111);
            this.lbl1X1.Name = "lbl1X1";
            this.lbl1X1.Size = new System.Drawing.Size(44, 16);
            this.lbl1X1.TabIndex = 0;
            this.lbl1X1.Text = "label7";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.textBox2);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(769, 603);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Numero perfecto";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(326, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "label6";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(305, 245);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 39);
            this.button3.TabIndex = 3;
            this.button3.Text = "Comprobar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(316, 174);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(210, 22);
            this.textBox2.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(189, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ingrese un numero";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(313, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Numero Perfecto";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Coral;
            this.label7.Location = new System.Drawing.Point(99, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 16);
            this.label7.TabIndex = 100;
            this.label7.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Coral;
            this.label18.Location = new System.Drawing.Point(19, 155);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 16);
            this.label18.TabIndex = 113;
            this.label18.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Coral;
            this.label17.Location = new System.Drawing.Point(19, 111);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 16);
            this.label17.TabIndex = 112;
            this.label17.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Coral;
            this.label8.Location = new System.Drawing.Point(19, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 16);
            this.label8.TabIndex = 115;
            this.label8.Text = "4";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Coral;
            this.label9.Location = new System.Drawing.Point(19, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 16);
            this.label9.TabIndex = 114;
            this.label9.Text = "3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Coral;
            this.label10.Location = new System.Drawing.Point(19, 367);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(14, 16);
            this.label10.TabIndex = 117;
            this.label10.Text = "6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Coral;
            this.label11.Location = new System.Drawing.Point(19, 308);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 16);
            this.label11.TabIndex = 116;
            this.label11.Text = "5";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Coral;
            this.label12.Location = new System.Drawing.Point(19, 480);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 16);
            this.label12.TabIndex = 119;
            this.label12.Text = "8";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Coral;
            this.label13.Location = new System.Drawing.Point(19, 425);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 16);
            this.label13.TabIndex = 118;
            this.label13.Text = "7";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Coral;
            this.label14.Location = new System.Drawing.Point(19, 527);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 16);
            this.label14.TabIndex = 120;
            this.label14.Text = "9";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Coral;
            this.label15.Location = new System.Drawing.Point(19, 587);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 16);
            this.label15.TabIndex = 121;
            this.label15.Text = "10";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Coral;
            this.label16.Location = new System.Drawing.Point(171, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 16);
            this.label16.TabIndex = 122;
            this.label16.Text = "2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Coral;
            this.label19.Location = new System.Drawing.Point(320, 67);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(14, 16);
            this.label19.TabIndex = 124;
            this.label19.Text = "4";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Coral;
            this.label20.Location = new System.Drawing.Point(248, 67);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(14, 16);
            this.label20.TabIndex = 123;
            this.label20.Text = "3";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Coral;
            this.label21.Location = new System.Drawing.Point(460, 67);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(14, 16);
            this.label21.TabIndex = 126;
            this.label21.Text = "6";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Coral;
            this.label22.Location = new System.Drawing.Point(388, 67);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(14, 16);
            this.label22.TabIndex = 125;
            this.label22.Text = "5";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Coral;
            this.label23.Location = new System.Drawing.Point(605, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(14, 16);
            this.label23.TabIndex = 128;
            this.label23.Text = "8";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Coral;
            this.label24.Location = new System.Drawing.Point(533, 67);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(14, 16);
            this.label24.TabIndex = 127;
            this.label24.Text = "7";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Coral;
            this.label25.Location = new System.Drawing.Point(744, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 16);
            this.label25.TabIndex = 130;
            this.label25.Text = "10";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Coral;
            this.label26.Location = new System.Drawing.Point(672, 67);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(14, 16);
            this.label26.TabIndex = 129;
            this.label26.Text = "9";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 775);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl1X1;
        private System.Windows.Forms.Label lbl1X7;
        private System.Windows.Forms.Label lbl1X9;
        private System.Windows.Forms.Label lbl1X8;
        private System.Windows.Forms.Label lbl1X6;
        private System.Windows.Forms.Label lbl1X5;
        private System.Windows.Forms.Label lbl1X4;
        private System.Windows.Forms.Label lbl1X3;
        private System.Windows.Forms.Label lbl1X2;
        private System.Windows.Forms.Label lbl9X10;
        private System.Windows.Forms.Label lbl9X7;
        private System.Windows.Forms.Label lbl9X9;
        private System.Windows.Forms.Label lbl9X8;
        private System.Windows.Forms.Label lbl9X6;
        private System.Windows.Forms.Label lbl9X5;
        private System.Windows.Forms.Label lbl9X4;
        private System.Windows.Forms.Label lbl9X3;
        private System.Windows.Forms.Label lbl9X2;
        private System.Windows.Forms.Label lbl9X1;
        private System.Windows.Forms.Label lbl8X10;
        private System.Windows.Forms.Label lbl8X7;
        private System.Windows.Forms.Label lbl8X9;
        private System.Windows.Forms.Label lbl8X8;
        private System.Windows.Forms.Label lbl8X6;
        private System.Windows.Forms.Label lbl8X5;
        private System.Windows.Forms.Label lbl8X4;
        private System.Windows.Forms.Label lbl8X3;
        private System.Windows.Forms.Label lbl8X2;
        private System.Windows.Forms.Label lbl8X1;
        private System.Windows.Forms.Label lbl7X10;
        private System.Windows.Forms.Label lbl7X7;
        private System.Windows.Forms.Label lbl7X9;
        private System.Windows.Forms.Label lbl7X8;
        private System.Windows.Forms.Label lbl7X6;
        private System.Windows.Forms.Label lbl7X5;
        private System.Windows.Forms.Label lbl7X4;
        private System.Windows.Forms.Label lbl7X3;
        private System.Windows.Forms.Label lbl7X2;
        private System.Windows.Forms.Label lbl7X1;
        private System.Windows.Forms.Label lbl6X10;
        private System.Windows.Forms.Label lbl6X7;
        private System.Windows.Forms.Label lbl6X9;
        private System.Windows.Forms.Label lbl6X8;
        private System.Windows.Forms.Label lbl6X6;
        private System.Windows.Forms.Label lbl6X5;
        private System.Windows.Forms.Label lbl6X4;
        private System.Windows.Forms.Label lbl6X3;
        private System.Windows.Forms.Label lbl6X2;
        private System.Windows.Forms.Label lbl6X1;
        private System.Windows.Forms.Label lbl5X10;
        private System.Windows.Forms.Label lbl5X7;
        private System.Windows.Forms.Label lbl5X9;
        private System.Windows.Forms.Label lbl5X8;
        private System.Windows.Forms.Label lbl5X6;
        private System.Windows.Forms.Label lbl5X5;
        private System.Windows.Forms.Label lbl5X4;
        private System.Windows.Forms.Label lbl5X3;
        private System.Windows.Forms.Label lbl5X2;
        private System.Windows.Forms.Label lbl5X1;
        private System.Windows.Forms.Label lbl4X10;
        private System.Windows.Forms.Label lbl4X7;
        private System.Windows.Forms.Label lbl4X9;
        private System.Windows.Forms.Label lbl4X8;
        private System.Windows.Forms.Label lbl4X6;
        private System.Windows.Forms.Label lbl4X5;
        private System.Windows.Forms.Label lbl4X4;
        private System.Windows.Forms.Label lbl4X3;
        private System.Windows.Forms.Label lbl4X2;
        private System.Windows.Forms.Label lbl4X1;
        private System.Windows.Forms.Label lbl3X10;
        private System.Windows.Forms.Label lbl3X7;
        private System.Windows.Forms.Label lbl3X9;
        private System.Windows.Forms.Label lbl3X8;
        private System.Windows.Forms.Label lbl3X6;
        private System.Windows.Forms.Label lbl3X5;
        private System.Windows.Forms.Label lbl3X4;
        private System.Windows.Forms.Label lbl3X3;
        private System.Windows.Forms.Label lbl3X2;
        private System.Windows.Forms.Label lbl3X1;
        private System.Windows.Forms.Label lbl2X10;
        private System.Windows.Forms.Label lbl2X7;
        private System.Windows.Forms.Label lbl2X9;
        private System.Windows.Forms.Label lbl2X8;
        private System.Windows.Forms.Label lbl2X6;
        private System.Windows.Forms.Label lbl2X5;
        private System.Windows.Forms.Label lbl2X4;
        private System.Windows.Forms.Label lbl2X3;
        private System.Windows.Forms.Label lbl2X2;
        private System.Windows.Forms.Label lbl2X1;
        private System.Windows.Forms.Label lbl1X10;
        private System.Windows.Forms.Label lbl10X10;
        private System.Windows.Forms.Label lbl10X7;
        private System.Windows.Forms.Label lbl10X9;
        private System.Windows.Forms.Label lbl10X8;
        private System.Windows.Forms.Label lbl10X6;
        private System.Windows.Forms.Label lbl10X5;
        private System.Windows.Forms.Label lbl10X4;
        private System.Windows.Forms.Label lbl10X3;
        private System.Windows.Forms.Label lbl10X2;
        private System.Windows.Forms.Label lbl10X1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label7;
    }
}


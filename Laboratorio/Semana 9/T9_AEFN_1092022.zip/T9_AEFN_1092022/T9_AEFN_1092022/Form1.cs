﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace T9_AEFN_1092022
{
    public partial class Form1 : Form
    {
        Motocicleta objMotocicleta = new Motocicleta();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
            int medelomoto;
            string marcamoto;
            double preciomoto, ivamoto;
            medelomoto = Convert.ToInt32(lblmodelo.Text);
            marcamoto = lblmarca.Text;
            preciomoto = Convert.ToDouble(lblprecio.Text);
            ivamoto = Convert.ToDouble(lbliva.Text);
            objMotocicleta.DefinirModelo(medelomoto);
            objMotocicleta.DefinirMarca(marcamoto);
            objMotocicleta.DefinirPrecio(preciomoto);
            objMotocicleta.DefinirIva(ivamoto);
            lblmostrardatos.Text = objMotocicleta.MostrarDatos();
        }
        public void Limpiar()
        {
            lblmostrardatos.Text = null;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Limpiar();
            objMotocicleta.Vender();
            lblmostrardatos.Text = objMotocicleta.MostrarDatos();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Limpiar();
            objMotocicleta.Devolver();
            lblmostrardatos.Text = objMotocicleta.MostrarDatos();
        }
    }
}

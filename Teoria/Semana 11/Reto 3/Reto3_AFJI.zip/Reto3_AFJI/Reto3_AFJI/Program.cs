﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto3_AFJI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nivel = new int[5];
            int[] niños = new int[5];
            string[] encargado = new string[5];
            int suma = 0;
            int suma2 = 0;
            string nombre;
            string responsable = " ";
            int maspersonas = 0;
            int a = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese adultos en nivel " + (i + 1));
                nivel[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de adultos nivel " + (i + 1) + " es de: " + nivel[i]);
                suma += nivel[i];
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese niños en nivel " + (i + 1));
                niños[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de niños nivel " + (i + 1) + " es de: " + niños[i]);
                suma2 += niños[i];
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el nombre del encargado en el nivel " + (i + 1));
                encargado[i] = Console.ReadLine();
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El nombre del encargado en el nivel " + (i + 1) + " es de: " + encargado[i]);
                nombre = encargado[i];
            }

            Console.WriteLine("La cantidad de adultos es de: " + suma);
            Console.WriteLine("La cantidad de niños es de: " + suma2);
            for (int i = 0; i < 5; i++)
            {
                if (a < niños[i])
                {
                    a = niños[i];

                    maspersonas = i;
                    responsable = encargado[i];
                }
            }
            Console.WriteLine("El nombre del responsable del nivel con más niños es: " + responsable);

            Console.ReadKey();
        }
    }
}

﻿class Program
{
    static void Main(string[] args)
    {
        int num1, num2, suma, resu;

        Console.WriteLine("Bienvenido ;)");

    
        Console.WriteLine("Ingrese un numero: ");
        num1 = Int32.Parse(Console.ReadLine());

       
        Console.WriteLine("Ingrese un segundo numero: ");
        num2 = Int32.Parse(Console.ReadLine());


        Console.WriteLine("Ingrese el resultado ");
        resu = Int32.Parse(Console.ReadLine());


       
        suma = num1 + num2;

        if (suma == resu)
        {
            Console.WriteLine("Resultado Correcto");
}
        else
        {
            Console.WriteLine("Resultado Incorrecto");
}


    }
}
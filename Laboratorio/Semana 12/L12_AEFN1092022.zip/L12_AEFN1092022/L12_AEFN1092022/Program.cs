﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_AEFN1092022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] t = new double[4, 5];
            double[,] t2 = new double[4, 5];
            double[,] tresultado = new double[4, 5];
            double acumulador=0;
            double contador=0;
            double promedio;

            Random rand = new Random();
            for(int i=0; i<4; i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    t[i, j] = rand.Next(100);
                    acumulador = acumulador + t[i, j];
                    contador++;
                }
            }
            promedio=acumulador/contador;
            Console.WriteLine("Parte 1 Laboratorio");
            Console.WriteLine("La suma de la matriz es: " +acumulador);
            Console.WriteLine("La suma de la matriz es: " + promedio);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    t2[i, j] = rand.Next(100);
                }
            }
            Console.WriteLine("\n");
            Console.WriteLine("Parte 2 Laboratorio");
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    tresultado[i, j] = t2[i, j] + t[i, j]; 
                    Console.WriteLine("fila " + i+ "columna " +j );
                }
            }
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_AEFN_1092022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numeros;
            numeros = new int[14];
            int l = 0;
            int num = 0;

            //Ingreso de datos
            for (int i = 0; i < 14; i++)
            {
                Console.WriteLine("Ingrese un numero");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }

            // Proceso
            for (int i = 0; i < 14; i++)
            {
                l = l + numeros[i];

                if (numeros[i] > 12)
                {
                    num++;
                }
            }

            double porcentaje = Convert.ToDouble((num * 100) / numeros.Length);

            Console.WriteLine("Suma de todos los numeros " + l);
            Console.WriteLine(num + "elementos están por encima del valor dado");
            Console.WriteLine("Porcentaje de los numeros mayores del valor dado  " + porcentaje + "%");

            Console.ReadKey();


        }
    }
    }

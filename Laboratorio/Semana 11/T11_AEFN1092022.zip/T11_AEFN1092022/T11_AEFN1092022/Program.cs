﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T11_AEFN1092022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] sec1;
            sec1 = new double[5];
            double[] sec2;
            sec2 = new double[5];
            double aprob1 = 0;
            double desaprob1 = 0;
            double aprob2 = 0;
            double desaprob2 = 0;
            double t1 = 0;
            double t2 = 0;
            double porapro1, pordespro1, porapro2, pordespro2, tproapro, tprodes, prom1, prom2, promtod;
            int a = 0;
            int b = 0;
            int c = 0;
            int d = 0;
            int q,l;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Sección 1");
                Console.WriteLine("Ingrese nota alumno: " + (i + 1));
                sec1[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Sección 2");
                Console.WriteLine("Ingrese nota alumno: " + (i + 1));
                sec2[i] = Convert.ToDouble(Console.ReadLine());

            }
            for (int i = 0; i < 5; i++)
            {
                t1 = t1 + sec1[i];
                if (sec1[i] >= 65)
                {
                    aprob1 = aprob1 + sec1[i];
                }
                else
                {
                    desaprob1 = desaprob1 + sec1[i];
                }

            }
            for (int i = 0; i < 5; i++)
            {
                t2 = t2 + sec2[i];
                if (sec2[i] >= 65)
                {
                    aprob2 = aprob2 + sec1[i];
                }
                else
                {
                    desaprob2 = desaprob2 + sec1[i];
                }
            }
            porapro1 = (aprob1 / t1) * 100;
            pordespro1 = (desaprob1 / t1) * 100;
            porapro2 = (aprob2 / t2) * 100;
            pordespro2 = (desaprob2 / t2) * 100;
            tproapro = ((aprob1 + aprob2) / (t1 + t2)) * 100;
            tprodes = ((desaprob1 + desaprob2) / (t1 + t2)) * 100;
            prom1 = t1 / 5;
            prom2 = t2 / 5;
            promtod = (t1 + t2) / 10;

            for (int i = 0; i < 5; i++)
            {

                if (sec1[i] > 90)
                {
                    a++;
                }
                if (sec2[i] > 90)
                {
                    b++;
                }



            }
            for (int i = 0; i < 5; i++)
            {

                if (sec1[i] < 75)
                {
                    c++;
                }
                if (sec2[i] < 75)
                {
                    d++;
                }



            }

            q = a + b;
            l = c + d;

            Console.WriteLine("Porcentaje de aprobacion de la sección 1:  " + porapro1);
            Console.WriteLine("Porcentaje de desaprobacion de la sección 1:  " + pordespro1);
            Console.WriteLine("Porcentaje de aprobacion sección 2: " + porapro2);
            Console.WriteLine("Porcentaje de desaprobacion sección 2: " + pordespro2);
            Console.WriteLine("Porcentaje de aprobacion de ambas secciones: " + tproapro);
            Console.WriteLine("Porcentaje de desaprpbacion de ambas secciones:" + tprodes);
            Console.WriteLine("Promedio notas sección 1: " + prom1);
            Console.WriteLine("Promedio notas sección 2: " + prom2);
            Console.WriteLine("Promedio total: " + promtod);
            Console.WriteLine("Estudiantes con promedio arriba de 90: " + q);
            Console.WriteLine("Estudiantes con promedio abajo de 75: " + l);

            Console.ReadKey();

        }
    }
}

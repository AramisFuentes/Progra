﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_AF1092022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tabControl1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.Enabled = true;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    tabControl1.SelectedTab = tabPage1;
                    break;
                case 1:
                    tabControl1.SelectedTab = tabPage2;
                    int resultado = 0;
                    for (int i = 1; i <= 1; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl1X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl1X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl1X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl1X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl1X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl1X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl1X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl1X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl1X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 1; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl1X10.Text = Convert.ToString(resultado);
                        }

                    }
                    for (int i = 1; i <= 2; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl2X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl2X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl2X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl2X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl2X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl2X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl2X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl2X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl2X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl2X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 3; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl3X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl3X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl3X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl3X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl3X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl3X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl3X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl3X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl3X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl3X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 4; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl4X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl4X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl4X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl4X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl4X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl4X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl4X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl4X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl4X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl4X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 5; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl5X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl5X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl5X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl5X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl5X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl5X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl5X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl5X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl5X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl5X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 6; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl6X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl6X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl6X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl6X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl6X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl6X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl6X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl6X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl6X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl6X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 7; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl7X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl7X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl7X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl7X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl7X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl7X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl7X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl7X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl7X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl7X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 8; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl8X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl8X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl8X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl8X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl8X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl8X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl8X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 8; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl8X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 8; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl8X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 8; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl8X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 9; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl9X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl9X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl9X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl9X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl9X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl9X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl9X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 8; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl9X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 9; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl9X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 9; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl9X10.Text = Convert.ToString(resultado);
                        }
                    }
                    for (int i = 1; i <= 10; i++)
                    {
                        for (int j = 1; j <= 1; j++)
                        {
                            resultado = i * j;
                            lbl10X1.Text = Convert.ToString(resultado);
                        }
                        for (int j = 2; j <= 2; j++)
                        {
                            resultado = i * j;
                            lbl10X2.Text = Convert.ToString(resultado);
                        }
                        for (int j = 3; j <= 3; j++)
                        {
                            resultado = i * j;
                            lbl10X3.Text = Convert.ToString(resultado);
                        }
                        for (int j = 4; j <= 4; j++)
                        {
                            resultado = i * j;
                            lbl10X4.Text = Convert.ToString(resultado);
                        }
                        for (int j = 5; j <= 5; j++)
                        {
                            resultado = i * j;
                            lbl10X5.Text = Convert.ToString(resultado);
                        }
                        for (int j = 6; j <= 6; j++)
                        {
                            resultado = i * j;
                            lbl10X6.Text = Convert.ToString(resultado);
                        }
                        for (int j = 7; j <= 7; j++)
                        {
                            resultado = i * j;
                            lbl10X7.Text = Convert.ToString(resultado);
                        }
                        for (int j = 8; j <= 8; j++)
                        {
                            resultado = i * j;
                            lbl10X8.Text = Convert.ToString(resultado);
                        }
                        for (int j = 9; j <= 9; j++)
                        {
                            resultado = i * j;
                            lbl10X9.Text = Convert.ToString(resultado);
                        }
                        for (int j = 10; j <= 10; j++)
                        {
                            resultado = i * j;
                            lbl10X10.Text = Convert.ToString(resultado);
                        }
                    }
                    break;
                case 2:
                    tabControl1.SelectedTab = tabPage3;

                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int numero, sumatoria = 0, i = 0;
            numero = Convert.ToInt32(textBox1.Text);
            do
            {
                sumatoria = sumatoria + i;
                i++;
            } while (i <= numero);
            label3.Text = Convert.ToString(sumatoria);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int numero, s, a, b = 0;
            numero = Convert.ToInt32(textBox2.Text);
            s = numero / 2;
            for (int j = 1; j <= s; j++)
            {
                a = numero % j;

                if (a == 0)
                    b = b + j;
            }
            if (b == numero)
                label6.Text = "El número " + numero + " es perfecto";
            else
                label6.Text = "El número " + numero + " no es perfecto";
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}

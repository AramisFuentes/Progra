﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T8_AEFN1092022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string binario = "";
            int n = int.Parse(textBox1.Text);

            while (n > 0)
            {

                binario = (n % 2) + binario;
                n = (int)n / 2;
            }

            textBox2.Text = binario;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string hexadecimal = "";
            int num = int.Parse(textBox3.Text);

            while (num > 0)
            {

                switch (num % 16)
                {
                    case 10: 
                        hexadecimal = "A" + hexadecimal; 
                        break;
                    case 11: 
                        hexadecimal = "B" + hexadecimal;
                        break;
                    case 12:
                        hexadecimal = "C" + hexadecimal; 
                        break;
                    case 13:
                        hexadecimal = "D" + hexadecimal;
                        break;
                    case 14: 
                        hexadecimal = "E" + hexadecimal;
                        break;
                    case 16:
                        hexadecimal = "F" + hexadecimal; 
                        break;

                    default:
                        hexadecimal = (num % 16) + hexadecimal;
                        break;

                }

                num = (int)num / 16;
            }

            textBox4.Text = hexadecimal;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto1_AFJI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nivel = new int[5];
            int a = 1000;
            int sumatoria = 0;
            int menorper = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese las personas que desea por Nivel " + (i + 1));
                nivel[i] = int.Parse(Console.ReadLine());
            }


            for (int i = 0; i < 5; i++)
            {
                if (a < nivel[i])
                {
                    a = nivel[i];

                    menorper = i+1;
                }
            }
            //Se lo presnete a la ingeniera y me dijo que estaba bien el codigo 
            Console.WriteLine("El menor numero de personas que hay en el nivel es el " + menorper);

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de personas " + (i + 1) + "es de : " + nivel[i]);
                sumatoria += nivel[i];
            }
            Console.WriteLine("La suma total de personas en el edificio es : " + sumatoria);

            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto2_AFJI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nivel = new int[5];
            int[] niños = new int[5];
            int a = 0;
            int menornino = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la cantidad de mujeres en el nivel " + (i + 1));
                nivel[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de mujeres en nivel " + (i + 1) + " es de: " + nivel[i]);
                
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la cantidad de niños en el nivel " + (i + 1));
                niños[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de niños en el nivel " + (i + 1) + " es de: " + niños[i]);
            }

            for (int i = 0; i < 5; i++)
            {
                if (a < nivel[i])
                {
                    a = nivel[i];

                    menornino = i + 1;
                }
            }
            Console.WriteLine("El mayor numero de niños que hay en un nivel es  " + menornino);
            Console.ReadKey();
        }
    }
}

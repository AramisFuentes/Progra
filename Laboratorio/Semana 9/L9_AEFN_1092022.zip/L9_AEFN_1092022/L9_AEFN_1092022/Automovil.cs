﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_AEFN_1092022
{
    internal class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Automovil()
        {
            this.modelo = 2019;
            this.precio =10000.00;
            this.marca = "";
            this.disponible = false;
            this.tipoCambioDolar = 7.50;
            this.descuentoAplicado = 0.00;
        }
        public void DefinirModelo(int unModelo)
        {
            this.modelo = unModelo;
        }
        public void DefinirPrecio(double unPrecio)
        {
            this.precio = unPrecio;
        }
        public void DefinirMarca(string unaMarca)
        {
            this.marca = unaMarca;
        }
        public void DefinirTipoCambio(double unTipoCambio)
        {
            this.tipoCambioDolar = unTipoCambio;
        }
        public double PrecioDolares()
        {
            double precioDolar = 0;
            precioDolar = this.precio / this.tipoCambioDolar;
            return precioDolar;
        }
        public void CambiarDisponibilidad()
        {
            if (disponible == true)
            {
                disponible = false;
            }
            else
            {
                disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {
            string texto = "";
            if (disponible == true)
            {
                texto = ("Disponible actualmente");
            }
            else
            {
                texto = "No esta disponible";
            }
            return texto;
        }
        public string MostrarInformacion()
        {
            string texto = "Marca: " + this.marca + Environment.NewLine + "Modelo: " + this.modelo + Environment.NewLine + "Precio de venta: Q" + this.precio + Environment.NewLine + "Precio en dolares $" + PrecioDolares() + Environment.NewLine + MostrarDisponibilidad();

            return texto;
        }
        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            this.precio = this.precio - descuentoAplicado;
            DefinirPrecio(this.precio);
        }
    }
}

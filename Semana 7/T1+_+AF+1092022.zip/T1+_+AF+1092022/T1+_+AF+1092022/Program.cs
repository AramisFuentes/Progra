﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1___AF_1092022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Mi segundo Programa");
            Console.WriteLine("Ingrese su nombre: ");
            Console.WriteLine("Ingrese su edad: ");
            Console.WriteLine("Ingrese su carrera: ");
            Console.WriteLine("Ingrese su carné: ");

            string Nombre = Console.ReadLine();
            string Edad = Console.ReadLine();
            string Carrera = Console.ReadLine();
            string Carne = Console.ReadLine();

            Console.WriteLine("Nombre:" + Nombre);
            
            Console.WriteLine("Edad:" + Edad);
            
            Console.WriteLine("Carrera" + Carrera);
            
            Console.WriteLine("Carné" + Carne);
            

            Console.Write("Nombre:" + Nombre+"tengo"+Edad+"años y estudio la carrera de"+Carrera+"Mi número de carné es:"+Carne);
            Console.ReadKey();
        }
    }
}

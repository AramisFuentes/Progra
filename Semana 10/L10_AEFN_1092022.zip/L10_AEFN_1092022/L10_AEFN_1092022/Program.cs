﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_AEFN_1092022
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Lab 10");
            Console.WriteLine("ingrese el cateto A");
            double catetoIngresado = double.Parse(Console.ReadLine());
            Console.WriteLine("ingrese angulo opuesto");
            double anguloIngresado = double.Parse(Console.ReadLine());

            double catetocalculadoA = 0;
            double catetocalculadoB= 0;
            double hipotenusacalculado = 0;
            double anguloposuestoAcalculado = 0;
            double anguloposuestoBcalculado = 0;
            double areacalculado = 0;

            TrianguloRectangulo objtriangulo = new TrianguloRectangulo(catetoIngresado,anguloIngresado);
            objtriangulo.CalcularGeometria(ref catetocalculadoA,ref catetocalculadoB, ref hipotenusacalculado, ref anguloposuestoAcalculado, ref anguloposuestoBcalculado, ref areacalculado);
            Console.WriteLine("el cateto a es: "+catetocalculadoA);
            Console.WriteLine("el cateto b es: "+catetocalculadoB );
            Console.WriteLine("el angulo opuesto a es: "+ anguloposuestoAcalculado);
            Console.WriteLine("el angulo opuesto b es: " + anguloposuestoBcalculado);
            Console.WriteLine("el area es: " + areacalculado);
            Console.WriteLine("la hipotenusa es: " + hipotenusacalculado);

            Console.ReadKey();
        }
        class TrianguloRectangulo
        {
            private double catetoA;
            private double anguloOpuestoA;
            double catetoB;
            double angulob;
            double hipotenusa;
            double area;

            public TrianguloRectangulo(double CatetoA, double AnguloOpuestoA)
            {
                catetoA = CatetoA;
                anguloOpuestoA = AnguloOpuestoA;
            }
            private double ObtenerCatetoA()
            {

                return catetoA;
            }
            public double ObtenerCatetoB()
            {
                catetoB = catetoA / Math.Tan(anguloOpuestoA);
                return catetoB;
            }
            public double ObtenerHipotenusa()
            {
                hipotenusa = Math.Sqrt((catetoA * catetoA + catetoB * catetoB));
                return hipotenusa;
            }
            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }
            public double ObtenerAnguloOpuestoB()
            {
                angulob = 180 - anguloOpuestoA - 90;
                return angulob;
            }
            public double ObtenerArea()
            {
                area = (catetoA * catetoB) / 2;
                return area;
            }
            public void CalcularGeometria(ref double unCatetoA, ref double unCatetoB, ref double unHipotenusa, ref double unAnguloOpuestoA, ref double unAnguloOpuestoB, ref double unArea)
            {
                unCatetoA = ObtenerCatetoA();
                unCatetoB = ObtenerCatetoB();
                unHipotenusa = ObtenerHipotenusa();
                unAnguloOpuestoA = ObtenerAnguloOpuestoA();
                unAnguloOpuestoB = ObtenerAnguloOpuestoB();
                unArea = ObtenerArea();
            }
        }
    }
}
